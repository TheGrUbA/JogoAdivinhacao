package com.example.aluno.jogoadivinhacao;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import java.util.Random;

public class MainActivity extends Activity implements View.onKeyListener{

    EditText numerin;
    Button butaozinho;
    TextView textinho;
    TextView tentativas;
    int qtdTentativas;
    Random r = new Random();
    int numro = r.nextInt((1000 + 1) + 1);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        butaozinho = findViewById(R.id.butao);
        qtdTentativas = 0;

        butaozinho.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                verificarPalpite();
            }
        });
    }

    @Override
    public boolean onKey(View v,int keyCode,KeyEvent event){
        if (keyCode == KeyEvent.KEYCODE_ENTER && event.getAction() != KeyEvent.ACTION_DOWN) {
            verificarPalpite();
            return true;
        }
        return false;
    }

    private void verificarPalpite(){
        numerin = findViewById(R.id.numro);
        int selected = Integer.parseInt(String.valueOf(numerin.getText()));
        if(selected > numro) {
            textinho.setText("Seu numero é maior carai");
            qtdTentativas++;
            tentativas.setText(String.valueOf(qtdTentativas));
            numerin.setText("");
        }
        else if(selected == numro) {
            textinho.setText("Aserto miseravi");
            butaozinho.setEnabled(false);
            numerin.setText("");
        }
        else {
            textinho.setText("Seu numero é menor cacete");
            qtdTentativas++;
            tentativas.setText(String.valueOf(qtdTentativas));
            numerin.setText("");
        }
    };
}
